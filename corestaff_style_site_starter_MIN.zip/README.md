# 极简静态站（Cloudflare Pages）

- 将全部文件上传到 GitHub 仓库根目录。
- Cloudflare Pages 连接仓库，Framework: None，Build command 留空，Output directory: /
